﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class MenuManagement : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene(1);
    }

   /* public void Score()
    {
        SceneManager.LoadScene(2);
    }*/

    public void Credit()
    {
        SceneManager.LoadScene(2);
    }

    public void back()
    {
        SceneManager.LoadScene(0);
    }


}

