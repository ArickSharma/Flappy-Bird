﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class BirdFly : MonoBehaviour
{

    public GameOverManager gameOverManager;
    public float velocity = 1;
    private Rigidbody2D rb2;


    // Start is called before the first frame update
    void Start()
    {

        rb2 = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.anyKeyDown)
        {
            rb2.velocity = Vector2.up * velocity;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {

        gameOverManager.GameOver();
    }



}
